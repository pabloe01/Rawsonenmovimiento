<?php

// Debes editar las pr�ximas dos l�neas de c�digo de acuerdo con tus preferencias
$email_from = "castilla-seguros@hotmail.com.ar";
$email_to = "castilla-seguros@hotmail.com.ar";
$email_subject = "Contacto desde el sitio web";

// Aqu� se deber�an validar los datos ingresados por el usuario
if(!isset($_POST['nombre']) ||
!isset($_POST['direccion']) ||
!isset($_POST['telef']) ||
!isset($_POST['mail']) ||
!isset($_POST['consulta'])) {

echo "<b>Ocurri� un error y el formulario no ha sido enviado. </b><br />";
echo "Por favor, vuelva atr�s y verifique la informaci�n ingresada<br />";
die();
}

$email_message = "Detalles del formulario de contacto:\n\n";
$email_message .= "Nombre: " . $_POST['nombre'] . "\n";
$email_message .= "E-mail: " . $_POST['mail'] . "\n";
$email_message .= "Tel�fono: " . $_POST['telef'] . "\n";
$email_message .= "Localidad: " . $_POST['local'] . "\n";
$email_message .= "Direcci�n: " . $_POST['direccion'] . "\n";
$email_message .= "Consulta: " . $_POST['consulta'] . "\n\n";

// Ahora se env�a el e-mail usando la funci�n mail() de PHP
$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);

echo "�El formulario se ha enviado con �xito!";

?>